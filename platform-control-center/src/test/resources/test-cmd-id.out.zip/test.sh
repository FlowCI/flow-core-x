echo " test.sh start "

export LANG=en_US.UTF-8
export LANGUAGE=en_US.UTF-8
export LC_ALL=en_US.UTF-8

source $HOME/.rvm/scripts/rvm
rvm use 2.3.1
rvm list

gem install xcpretty

# sleep 10
# echo " test.sh finsih "

cd ~/work/test/YYiOS
fastlane gym --scheme Yeyu --export_method development
